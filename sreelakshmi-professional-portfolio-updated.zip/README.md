# Sreelakshmi Sajeevan — Professional Portfolio

## Files
- `index.html` — complete one-page responsive portfolio
- `resume.pdf` — add your current resume here before publishing

## Before publishing
1. Replace `YOUR_EMAIL@example.com` in `index.html`.
2. Replace the LinkedIn and GitHub URLs.
3. Put your final resume in this folder as `resume.pdf`.
4. Optionally replace the `SS` avatar with a professional photo.
5. Publish the folder using GitHub Pages, Netlify, or another static hosting service.

The page is responsive and does not require a backend.
